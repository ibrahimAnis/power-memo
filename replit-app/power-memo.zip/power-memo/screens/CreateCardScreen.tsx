import { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, KeyboardAvoidingView, Platform, Image } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { toast } from 'sonner-native';
import Ionicons from '@expo/vector-icons/Ionicons'; // Added import for Ionicons


export default function CreateCardScreen() {
  const navigation = useNavigation();
  const route = useRoute();
  const { deckId } = route.params || {};

  const [front, setFront] = useState('');
  const [back, setBack] = useState('');
  const [frontType, setFrontType] = useState('text'); // Added state for front type
  const [backType, setBackType] = useState('text'); // Added state for back type
  const [codeLanguage, setCodeLanguage] = useState('javascript'); // Added state for code language
  const languageOptions = ['javascript', 'python', 'java', 'c++']; // Added language options


  const handleCreate = () => {
    if (!front.trim() || !back.trim()) {
      toast.error('Please fill in both sides of the card');
      return;
    }

    // Here we would save the card, using in-memory data for now
    toast.success('Card created successfully!');
    navigation.goBack();
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.form}>
          <Text style={styles.label}>Front</Text>
          <View style={styles.typeSelector}>
            <TouchableOpacity
              style={[styles.typeButton, frontType === 'text' && styles.selectedType]}
              onPress={() => setFrontType('text')}
            >
              <Text style={styles.typeButtonText}>Text</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.typeButton, frontType === 'image' && styles.selectedType]}
              onPress={() => setFrontType('image')}
            >
              <Text style={styles.typeButtonText}>Image</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.typeButton, frontType === 'code' && styles.selectedType]}
              onPress={() => setFrontType('code')}
            >
              <Text style={styles.typeButtonText}>Code</Text>
            </TouchableOpacity>
          </View>

          {frontType === 'text' && (
            <TextInput
              style={[styles.input, styles.textArea]}
              value={front}
              onChangeText={setFront}
              placeholder="Enter the question..."
              placeholderTextColor="#999"
              multiline
              numberOfLines={4}
              textAlignVertical="top"
            />
          )}

          {frontType === 'image' && (
            <TouchableOpacity style={styles.imageUpload}>
              <Ionicons name="image-outline" size={24} color="#4A90E2" />
              <Text style={styles.imageUploadText}>Upload Image</Text>
              <Image source={{uri: front}} style={styles.previewImage}/> {/*Added Image preview*/}
            </TouchableOpacity>
          )}

          {frontType === 'code' && (
            <View>
              <View style={styles.languageSelector}>
                {languageOptions.map(lang => (
                  <TouchableOpacity
                    key={lang}
                    style={[styles.langButton, codeLanguage === lang && styles.selectedLang]}
                    onPress={() => setCodeLanguage(lang)}
                  >
                    <Text style={styles.langButtonText}>{lang}</Text>
                  </TouchableOpacity>
                ))}
              </View>
              <TextInput
                style={[styles.input, styles.codeArea]}
                value={front}
                onChangeText={setFront}
                placeholder="Enter your code..."
                placeholderTextColor="#999"
                multiline
                numberOfLines={8}
                textAlignVertical="top"
                fontFamily="monospace"
              />
            </View>
          )}

          <Text style={styles.label}>Back</Text>
          {/* Similar implementation for the back side */}
          <View style={styles.typeSelector}>
            <TouchableOpacity
              style={[styles.typeButton, backType === 'text' && styles.selectedType]}
              onPress={() => setBackType('text')}
            >
              <Text style={styles.typeButtonText}>Text</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.typeButton, backType === 'image' && styles.selectedType]}
              onPress={() => setBackType('image')}
            >
              <Text style={styles.typeButtonText}>Image</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.typeButton, backType === 'code' && styles.selectedType]}
              onPress={() => setBackType('code')}
            >
              <Text style={styles.typeButtonText}>Code</Text>
            </TouchableOpacity>
          </View>

          {backType === 'text' && (
            <TextInput
              style={[styles.input, styles.textArea]}
              value={back}
              onChangeText={setBack}
              placeholder="Enter the answer..."
              placeholderTextColor="#999"
              multiline
              numberOfLines={4}
              textAlignVertical="top"
            />
          )}

          {backType === 'image' && (
            <TouchableOpacity style={styles.imageUpload}>
              <Ionicons name="image-outline" size={24} color="#4A90E2" />
              <Text style={styles.imageUploadText}>Upload Image</Text>
              <Image source={{uri: back}} style={styles.previewImage}/> {/*Added Image preview*/}
            </TouchableOpacity>
          )}

          {backType === 'code' && (
            <View>
              <View style={styles.languageSelector}>
                {languageOptions.map(lang => (
                  <TouchableOpacity
                    key={lang}
                    style={[styles.langButton, codeLanguage === lang && styles.selectedLang]}
                    onPress={() => setCodeLanguage(lang)}
                  >
                    <Text style={styles.langButtonText}>{lang}</Text>
                  </TouchableOpacity>
                ))}
              </View>
              <TextInput
                style={[styles.input, styles.codeArea]}
                value={back}
                onChangeText={setBack}
                placeholder="Enter your code..."
                placeholderTextColor="#999"
                multiline
                numberOfLines={8}
                textAlignVertical="top"
                fontFamily="monospace"
              />
            </View>
          )}


          <TouchableOpacity style={styles.button} onPress={handleCreate}>
            <Text style={styles.buttonText}>Create Card</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F6F7',
  },
  scrollContent: {
    flexGrow: 1,
    padding: 16,
  },
  form: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1A1A1A',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#F5F6F7',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#E1E1E1',
  },
  textArea: {
    height: 120,
  },
  button: {
    backgroundColor: '#4A90E2',
    borderRadius: 8,
    padding: 16,
    alignItems: 'center',
    marginTop: 8,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  typeSelector: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  typeButton: {
    backgroundColor: '#f0f0f0',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 4,
    marginRight: 8,
  },
  selectedType: {
    backgroundColor: '#4A90E2',
  },
  typeButtonText: {
    color: '#333',
  },
  imageUpload: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
  },
  imageUploadText: {
    marginLeft: 8,
    color: '#4A90E2',
  },
  languageSelector: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  langButton: {
    backgroundColor: '#f0f0f0',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 4,
    marginRight: 8,
  },
  selectedLang: {
    backgroundColor: '#4A90E2',
  },
  langButtonText: {
    color: '#333',
  },
  codeArea: {
    height: 200,
  },
  previewImage: {
    width: 50,
    height: 50,
    marginRight: 8,
  }
});