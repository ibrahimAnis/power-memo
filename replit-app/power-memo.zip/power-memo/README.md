# power-memo
Power memo to build flashcards and revise
